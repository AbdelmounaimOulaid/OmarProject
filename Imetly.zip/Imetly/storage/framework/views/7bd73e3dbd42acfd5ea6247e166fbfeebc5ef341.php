<div>
    <p><strong>Email:</strong> <?php echo e($email); ?></p>
    <p><strong>Name:</strong>  <?php echo e($name); ?></p>
    <p><strong>Subject:</strong>  <?php echo e($subject); ?></p>
    <p><strong>Message:</strong>  <?php echo e($text); ?></p>
</div>
<?php /**PATH C:\Users\oulai\OneDrive\Bureau\Imetly\Project\Imetly\resources\views/blank.blade.php ENDPATH**/ ?>