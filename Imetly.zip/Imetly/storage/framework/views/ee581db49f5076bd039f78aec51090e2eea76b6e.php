<!-- Navbar & Hero Start -->
<div class="container-full position-relative p-0">
  <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
    <a href="/" class="navbar-brand p-0">
      <h1 class="m-0">Imeetly<span class="fs-5"></span></h1>
      <!-- <img src="img/logo.png" alt="Logo"> -->
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
      <span class="fa fa-bars"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <div class="navbar-nav ms-auto py-0">
        <a href="/" <?php if(Session::get('page')=='home' ): ?> class="nav-item nav-link active" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>Home</a>
        <a href="/about" <?php if(Session::get('page')=='about' ): ?> class="nav-item nav-link active" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>About</a>
        <a href="/services" <?php if(Session::get('page')=='services' ): ?> class="nav-item nav-link active" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>Services</a>
        <a href="/plans" <?php if(Session::get('page')=='plans' ): ?> class="nav-item nav-link active" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>Plans</a>
        <a href="/contact" <?php if(Session::get('page')=='contact' ): ?> class="nav-item nav-link active" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>Contact</a>
        <?php if(auth()->guard()->check()): ?>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
          <?php echo csrf_field(); ?>
    
        </form>
        <a href="#" class="nav-item nav-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
       
        <?php else: ?>
        <a href="/register" <?php if(Session::get('page')=='register' ): ?> class="nav-item nav-link" <?php else: ?> class="nav-item nav-link" <?php endif; ?>>Register</a>
        <?php endif; ?>
      </div>
      <butaton type="button" class="btn text-white ms-3" data-bs-toggle="modal" data-bs-target="#searchModal"><i class="fa fa-search"></i></butaton>

    </div>
  </nav>
  <div class="container-full py-5 bg-dark hero-header mb-5">
    <?php echo $__env->yieldContent('nav-content'); ?>
  </div>
</div>
<!-- Navbar & Hero End --><?php /**PATH C:\Users\oulai\OneDrive\Bureau\Imetly\Project\Imetly\resources\views/Layouts/navbar.blade.php ENDPATH**/ ?>