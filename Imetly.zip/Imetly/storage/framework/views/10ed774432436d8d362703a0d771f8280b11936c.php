
<?php $__env->startSection('title','Register'); ?>
<?php $__env->startSection('nav-content'); ?>
<div class="container my-5 py-5 px-lg-5">
    <div class="row g-5 py-5">
        <div class="col-12 text-center">
            <h1 class="text-white animated zoomIn">Register</h1>
            <hr class="bg-white mx-auto mt-0" style="width: 90px;">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Contact Start -->
<div class="container-full py-5">
    <div class="container px-lg-5">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="section-title position-relative text-center mb-5 pb-2 wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="position-relative d-inline text-primary ps-4">Register</h6>
                    <h2 class="mt-2">Join us now</h2>
                </div>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error:</strong> Please fix the following issues:
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php endif; ?>

                <div class="wow fadeInUp" data-wow-delay="0.3s">
                    <form action="<?php echo e(Route('registerCheck')); ?>" method="POST"> <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="firstname" id="firstname" placeholder="Your First Name">
                                    <label for="firstname"> First Name</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control" name="lastname" id="lastname" placeholder="Your Last Name">
                                    <label for="lastname">Last Name</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <select class="form-control" name="job" id="job">
                                        <option value="" disabled selected>Select an option</option>
                                        <option value="student">Student</option>
                                        <option value="employee">Employee</option>
                                        <option value="candidate">Candidate</option>
                                        <option value="teacher">Teacher</option>
                                        <!-- Add more options here -->
                                    </select>
                                    <label for="job">You are...</label>
                                    <div class="select-arrow"></div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Your Email">
                                    <label for="email">Email</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Your Password">
                                    <label for="password">Password</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <button class="btn btn-primary w-100 py-3" type="submit">Register</button>
                                <p>Already a member ?<a href="/login"> <strong>Login</strong></a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./Layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\oulai\OneDrive\Bureau\Imetly\Project\Imetly\resources\views/register.blade.php ENDPATH**/ ?>