<div>
    <p><strong>Email:</strong> {{ $email }}</p>
    <p><strong>Name:</strong>  {{ $name }}</p>
    <p><strong>Subject:</strong>  {{ $subject }}</p>
    <p><strong>Message:</strong>  {{ $text }}</p>
</div>
